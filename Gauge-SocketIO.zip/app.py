from flask import Flask, render_template, jsonify
from flask_socketio import SocketIO
import dash
from dash import html, dcc
import dash_bootstrap_components as dbc
import dash_daq as daq
from dash.dependencies import Input, Output
from dash_bootstrap_templates import ThemeSwitchAIO
import psutil

template_theme2 = "darkly"
template_theme1 = "flatly"
url_theme2 = dbc.themes.DARKLY
url_theme1 = dbc.themes.FLATLY

# Initialize Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app)

# Initialize Dash app
dash_app = dash.Dash(__name__, server=app, external_stylesheets=[dbc.themes.BOOTSTRAP])

var_style = {"width": "15rem", "height": "12rem", "margin": "5px"}
var_color = {"gradient":True,"ranges":{"green":[0,60],"yellow":[60,80],"red":[80,100]}}

cpu_card = dbc.Card(dbc.CardBody([
                        html.A(
                        daq.Gauge(
                            id='cpu-gauge',
                            label="AMD Ryzen 7 5700U",
                            min=0,
                            max=100,
                            size=100,
                            showCurrentValue=True,
                            color=var_color
                        ),
                        href="/cpu?endpoint=cpu",  # Replace with your desired URL
                    )
                ]), style=var_style)
memory_card = dbc.Card(dbc.CardBody([
                        html.A(
                        daq.Gauge(
                            id='memory-gauge',
                            label="Memory Usage",
                            min=0,
                            max=100,
                            size=100,
                            showCurrentValue=True,
                            color=var_color
                        ),
                        href="/memory?endpoint=memory",  # Replace with your desired URL
                    )
                ]), style=var_style)   
disk_card = dbc.Card(dbc.CardBody([
                        html.A(
                        daq.Gauge(
                            id='disk-gauge',
                            label="Disk Usage",
                            min=0,
                            max=100,
                            size=100,
                            showCurrentValue=True,
                            color=var_color
                        ),
                        href="/disk?endpoint=disk",  # Replace with your desired URL
                    )
                ]), style=var_style)             
outer_card = dbc.Card(
        dbc.CardBody([
        dbc.Row([dbc.Col(ThemeSwitchAIO(aio_id="theme", themes=[url_theme1, url_theme2]), sm=4)]),
        html.H3("System Resources Dashboard with SockerIO", style={'textAlign': 'center'}),
            dbc.Row([            
                dbc.Col(cpu_card, width="auto"),
                dbc.Col(memory_card, width="auto"),
                dbc.Col(disk_card, width="auto")
            ], justify='around')  # This will space out the columns evenly
        ]),
    style={"margin": "20px"}
    )

dash_app.layout = html.Div([
    outer_card,
    dcc.Interval(
        id='interval-component',
        interval=1*1000,  # in milliseconds
        n_intervals=0
    )
],)

# Update the cpu gauge in real-time
@dash_app.callback(Output('cpu-gauge', 'value'), [Input('interval-component', 'n_intervals')])
def update_cpu_gauge(n):
    cpu_usage = psutil.cpu_percent()
    return cpu_usage
# Update the memory gauge in real-time
@dash_app.callback(Output('memory-gauge', 'value'), [Input('interval-component', 'n_intervals')])
def update_memory_gauge(n):
    memory_usage = psutil.virtual_memory().percent
    return memory_usage
# Update the disk gauge in real-time
@dash_app.callback(Output('disk-gauge', 'value'), [Input('interval-component', 'n_intervals')])
def update_disk_gauge(n):
    disk_usage = psutil.disk_usage('/').percent
    return disk_usage

# Flask route for the main page
@app.route('/')
def index():
    return render_template('index.html')

# Flask route for CPU usage with auto-refreshing gauge display
@app.route('/cpu')
def cpu():
    return render_template('generic.html')  # Assuming your HTML file is named 'cpu.html'

# Flask route for memory usage with auto-refreshing gauge display
@app.route('/memory')
def memory():
    return render_template('generic.html')  # Assuming your HTML file is named 'memory.html'

# Flask route for disk usage with auto-refreshing gauge display
@app.route('/disk')
def disk():
    return render_template('generic.html')  # Assuming your HTML file is named 'disk.html'

# Endpoint to get current CPU usage
@app.route('/get_cpu_usage')
def get_cpu_usage():
    cpu_usage = psutil.cpu_percent()
    return jsonify({'cpu_usage': cpu_usage})

# Endpoint to get current memory usage
@app.route('/get_memory_usage')
def get_memory_usage():
    memory_usage = psutil.virtual_memory().percent
    return jsonify({'memory_usage': memory_usage})

# Endpoint to get current disk usage
@app.route('/get_disk_usage')
def get_disk_usage():
    disk_usage = psutil.disk_usage('/').percent
    return jsonify({'disk_usage': disk_usage})

# SocketIO event to emit CPU usage
@socketio.on('get_cpu_data')
def handle_cpu_data():
    cpu_usage = psutil.cpu_percent()
    socketio.emit('cpu_data', {'data': cpu_usage})

# SocketIO event to emit memory usage
@socketio.on('get_memory_data')
def handle_memory_data():
    memory_usage = psutil.virtual_memory().percent
    socketio.emit('memory_data', {'data': memory_usage})

# SocketIO event to emit disk usage
@socketio.on('get_disk_data')
def handle_disk_data():
    disk_usage = psutil.disk_usage('/').percent
    socketio.emit('disk_data', {'data': disk_usage})

if __name__ == '__main__':
    socketio.run(app,debug=False,allow_unsafe_werkzeug=False, port=8055)
