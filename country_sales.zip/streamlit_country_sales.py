import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime
import numpy as np
from fpdf import FPDF
import matplotlib.pyplot as plt
import seaborn as sns
from io import BytesIO
import geopandas as gpd
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas

# Set page configuration
st.set_page_config(page_title="G20 Sales Dashboard", layout="wide")

# [Previous CSS styles remain the same]
st.markdown("""
    <style>
        .stTabs [data-baseweb="tab-list"] {
            gap: 8px;
        }
        .stTabs [data-baseweb="tab"] {
            border: 1px solid #dee2e6;
            border-radius: 4px 4px 0 0;
            padding: 10px 24px;
        }
        .stTabs [data-baseweb="tab-panel"] {
            border: 1px solid #dee2e6;
            border-radius: 0 0 4px 4px;
            padding: 16px;
        }
        div[data-testid="stMetricValue"] {
            background-color: #f8f9fa;
            padding: 10px;
            border-radius: 4px;
            border: 1px solid #dee2e6;
        }
        iframe {
            border: 1px solid #dee2e6;
            border-radius: 4px;
        }
        div[data-testid="stDataFrame"] {
            border: 1px solid #dee2e6;
            border-radius: 4px;
            padding: 8px;
        }
    </style>
""", unsafe_allow_html=True)

# Add title
st.title("🌎 G20 Sales Dashboard")

@st.cache_data
def load_data():
    try:
        df = pd.read_csv('country_sales.csv')
        df['Date'] = pd.to_datetime(df['Date'])
        return df, None
    except Exception as e:
        return None, str(e)

# Load data
@st.cache_data
def load_map_data():
    try:
        return gpd.read_file(gpd.datasets.get_path('naturalearth_lowres'))
    except:
        return None

df, error = load_data()

if error:
    st.error(f"Error loading data: {error}")
    st.stop()

# Define categories and subcategories mapping
categories_map = {
    'Electronics': ['All', 'Smartphones', 'Laptops', 'Tablets', 'Wearables'],
    'Automotive': ['All', 'Cars', 'Motorcycles', 'Auto Parts', 'Electric Vehicles'],
    'Fashion': ['All', 'Luxury Apparel', 'Casual Wear', 'Accessories', 'Footwear'],
    'Industrial': ['All', 'Machinery', 'Raw Materials', 'Tools', 'Construction'],
    'Consumer Goods': ['All', 'Home Appliances', 'Personal Care', 'Food & Beverage', 'Home Decor']
}

# Country name mapping for geopandas
country_name_mapping = {
    'United States': 'United States of America',
    'Russia': 'Russian Federation',
    'South Korea': 'Korea, Republic of',
    'European Union': 'Europe'
}

# Sidebar filters
st.sidebar.header("Filters")

# Date range filter
min_date = df['Date'].min()
max_date = df['Date'].max()
date_range = st.sidebar.date_input(
    "Select Date Range",
    value=[min_date, max_date],
    min_value=min_date,
    max_value=max_date
)

# Country dropdown with "All" option
countries = sorted(df['Country'].unique())
country_options = ['All'] + countries
selected_country = st.sidebar.selectbox(
    "Select Country",
    country_options
)

# Category and Subcategory filters
categories = ['All'] + sorted(df['Category'].unique())
selected_category = st.sidebar.selectbox(
    "Select Category",
    categories
)

# Dynamic subcategory options based on selected category
if selected_category == 'All':
    subcategory_options = ['All']
    selected_subcategory = 'All'
else:
    subcategory_options = categories_map[selected_category]
    selected_subcategory = st.sidebar.selectbox(
        "Select Subcategory",
        subcategory_options
    )

# Apply filters
filtered_df = df[
    (df['Date'].dt.date >= date_range[0]) &
    (df['Date'].dt.date <= date_range[1])
]

if selected_country != 'All':
    filtered_df = filtered_df[filtered_df['Country'] == selected_country]

if selected_category != 'All':
    filtered_df = filtered_df[filtered_df['Category'] == selected_category]
    if selected_subcategory != 'All':
        filtered_df = filtered_df[filtered_df['Subcategory'] == selected_subcategory]

# Create three columns for KPIs with styled containers
st.markdown('<div style="padding: 10px; border: 1px solid #dee2e6; border-radius: 4px; margin-bottom: 16px;">', unsafe_allow_html=True)
col1, col2, col3 = st.columns(3)

with col1:
    total_sales = filtered_df['Sales'].sum()
    st.metric("Total Sales", f"${total_sales:,.0f}")

with col2:
    avg_sales = filtered_df['Sales'].mean()
    st.metric("Average Sales", f"${avg_sales:,.0f}")

with col3:
    total_cities = filtered_df['City'].nunique()
    st.metric("Total Cities", total_cities)
st.markdown('</div>', unsafe_allow_html=True)

# Create tabs for different visualizations
tab1, tab2, tab3, tab4 = st.tabs([
    "📍 Geographic Analysis",
    "🏙️ City Performance",
    "📊 Category Analysis",
    "📈 Time Series"
])

with tab1:
    st.subheader("Sales by Country")
    country_sales = filtered_df.groupby('Country')['Sales'].sum().reset_index()
    
    fig_map = px.choropleth(
        country_sales,
        locations='Country',
        locationmode='country names',
        color='Sales',
        hover_name='Country',
        color_continuous_scale='Viridis',
        title='Total Sales by Country'
    )
    fig_map.update_layout(
        height=500,
        geo=dict(
            showframe=False,
            showcoastlines=True,
            projection_type='equirectangular'
        )
    )
    st.plotly_chart(fig_map, use_container_width=True)

with tab2:
    # Top 10 cities by sales
    st.subheader("Top 10 Cities by Sales")
    city_sales = filtered_df.groupby(['City', 'Country'])['Sales'].sum().reset_index()
    city_sales = city_sales.nlargest(10, 'Sales')
    
    fig_cities = px.bar(
        city_sales,
        x='City',
        y='Sales',
        color='Country',
        title="Top 10 Cities by Sales",
        labels={'Sales': 'Total Sales'},
        custom_data=['Country']
    )
    fig_cities.update_layout(xaxis_tickangle=-45)
    st.plotly_chart(fig_cities, use_container_width=True)
    
    # Population vs Sales scatter plot
    st.subheader("City Population vs Sales")
    fig_scatter = px.scatter(
        filtered_df,
        x='City_Population',
        y='Sales',
        color='Category' if selected_category == 'All' else 'Subcategory',
        hover_data=['City', 'Country'],
        title='Sales vs City Population',
        custom_data=['Country', 'City']
    )
    st.plotly_chart(fig_scatter, use_container_width=True)

with tab3:
    col1, col2 = st.columns(2)
    
    with col1:
        if selected_category == 'All':
            st.subheader("Sales by Category")
            category_sales = filtered_df.groupby('Category')['Sales'].sum()
            fig_categories = px.pie(
                values=category_sales.values,
                names=category_sales.index,
                title="Sales Distribution by Category"
            )
            st.plotly_chart(fig_categories, use_container_width=True)
        else:
            st.subheader(f"Sales by Subcategory ({selected_category})")
            subcategory_sales = filtered_df.groupby('Subcategory')['Sales'].sum()
            fig_subcategories = px.pie(
                values=subcategory_sales.values,
                names=subcategory_sales.index,
                title=f"Sales Distribution by Subcategory in {selected_category}"
            )
            st.plotly_chart(fig_subcategories, use_container_width=True)
    
    with col2:
        st.subheader("Category Performance")
        cat_performance = filtered_df.groupby('Category')['Sales'].agg(['sum', 'mean', 'count']).round(2)
        cat_performance.columns = ['Total Sales', 'Average Sales', 'Number of Transactions']
        st.dataframe(cat_performance.style.format({
            'Total Sales': '${:,.2f}',
            'Average Sales': '${:,.2f}',
            'Number of Transactions': '{:,.0f}'
        }))

with tab4:
    st.subheader("Sales Trend Over Time")
    if selected_category == 'All':
        daily_sales = filtered_df.groupby(['Date', 'Category'])['Sales'].sum().reset_index()
        color_column = 'Category'
    else:
        daily_sales = filtered_df.groupby(['Date', 'Subcategory'])['Sales'].sum().reset_index()
        color_column = 'Subcategory'

    fig_trend = px.line(
        daily_sales,
        x='Date',
        y='Sales',
        color=color_column,
        title='Daily Sales Trend'
    )
    fig_trend.update_layout(
        xaxis=dict(
            rangeselector=dict(
                buttons=list([
                    dict(count=1, label="1m", step="month", stepmode="backward"),
                    dict(count=6, label="6m", step="month", stepmode="backward"),
                    dict(count=1, label="YTD", step="year", stepmode="todate"),
                    dict(count=1, label="1y", step="year", stepmode="backward"),
                    dict(step="all")
                ])
            )
        )
    )
    st.plotly_chart(fig_trend, use_container_width=True)
    
    # Monthly aggregation
    st.subheader("Monthly Sales Summary")
    monthly_sales = filtered_df.groupby([filtered_df['Date'].dt.to_period('M')])['Sales'].agg(['sum', 'mean', 'count'])
    monthly_sales.index = monthly_sales.index.astype(str)
    monthly_sales.columns = ['Total Sales', 'Average Sales', 'Number of Transactions']
    st.dataframe(monthly_sales.style.format({
        'Total Sales': '${:,.2f}',
        'Average Sales': '${:,.2f}',
        'Number of Transactions': '{:,.0f}'
    }))


# Add Data Table section outside of tabs
st.markdown("---")
st.subheader("📋 Detailed Data")
st.dataframe(
    filtered_df.style.format({
        'Sales': '${:,.2f}',
        'City_Population': '{:,.0f}'
    }),
    height=400
)

# PDF Generation Function
def create_country_report(df, country, page_num=1):
    """Create a simplified PDF report for a specific country"""
    # Filter data for the country
    country_data = df[df['Country'] == country]
    
    # Create PDF
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()
    
    # Page number
    pdf.set_font('Arial', 'I', 8)
    pdf.cell(0, 10, f'Page {page_num}', 0, 1, 'R')
    
    # Title
    pdf.set_font('Arial', 'B', 16)
    pdf.cell(0, 10, f'Sales Report - {country}', 0, 1, 'C')
    pdf.ln(10)

    # Create table with key metrics
    pdf.set_font('Arial', 'B', 12)
    pdf.cell(0, 10, 'Key Metrics:', 0, 1)
    pdf.ln(5)

    # Table settings
    cell_height = 10
    col_width = 95
    
    # Function to create table row
    def add_table_row(label, value, bold_label=True):
        pdf.set_fill_color(240, 240, 240)
        if bold_label:
            pdf.set_font('Arial', 'B', 10)
        else:
            pdf.set_font('Arial', '', 10)
        pdf.cell(col_width, cell_height, label, 1, 0, 'L', True)
        pdf.set_font('Arial', '', 10)
        pdf.cell(col_width, cell_height, str(value), 1, 1, 'L')

    # Add rows to table
    total_sales = country_data['Sales'].sum()
    avg_sales = country_data['Sales'].mean()
    num_cities = country_data['City'].nunique()
    
    add_table_row('Total Sales:', f'${total_sales:,.2f}')
    add_table_row('Average Sales:', f'${avg_sales:,.2f}')
    add_table_row('Number of Cities:', str(num_cities))
    
    # Add city details
    pdf.ln(10)
    pdf.set_font('Arial', 'B', 12)
    pdf.cell(0, 10, 'City Details:', 0, 1)
    pdf.ln(5)

    city_sales = country_data.groupby('City')['Sales'].sum()
    for city, sales in city_sales.items():
        add_table_row(city, f'${sales:,.2f}', False)

    # Add category details
    pdf.ln(10)
    pdf.set_font('Arial', 'B', 12)
    pdf.cell(0, 10, 'Category Details:', 0, 1)
    pdf.ln(5)

    category_sales = country_data.groupby('Category')['Sales'].sum()
    for category, sales in category_sales.items():
        add_table_row(category, f'${sales:,.2f}', False)

    return pdf


# Add Generate PDF button
st.sidebar.markdown("---")
if st.sidebar.button("Generate PDF Report"):
    try:
        # Create a PDF with all countries
        merged_pdf = FPDF()
        
        # Progress bar
        progress_bar = st.sidebar.progress(0)
        status_text = st.sidebar.empty()
        
        # Generate report for each country
        countries = sorted(df['Country'].unique())
        
        # Create a BytesIO object to store the PDF
        pdf_buffer = BytesIO()
        
        for i, country in enumerate(countries):
            # Update progress
            progress = (i + 1) / len(countries)
            progress_bar.progress(progress)
            status_text.text(f"Processing {country}...")
            
            # Create country report
            country_pdf = create_country_report(df, country, i + 1)
            
            # Add pages to merged PDF
            for page_num in range(1, country_pdf.page + 1):
                merged_pdf.add_page()
                merged_pdf.pages[merged_pdf.page] = country_pdf.pages[page_num]
        
        # Save to BytesIO buffer
        merged_pdf.output(pdf_buffer)
        
        # Clean up progress indicators
        progress_bar.empty()
        status_text.empty()
        
        # Create download button
        st.sidebar.download_button(
            label="Download PDF Report",
            data=pdf_buffer.getvalue(),
            file_name="sales_report.pdf",
            mime="application/pdf"
        )
        
        # Success message
        st.sidebar.success("PDF generated successfully! Click the download button above.")
        
        # Close buffer
        pdf_buffer.close()
        
    except Exception as e:
        st.sidebar.error(f"An error occurred: {str(e)}")

# Footer
st.markdown("---")
st.markdown("""

""")
st.markdown("Dashboard created with Streamlit and Plotly")