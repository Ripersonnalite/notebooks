import pandas as pd
import numpy as np
from datetime import datetime, timedelta

# Define G20 countries and their top 2 most populated cities with populations (2024 estimates)
g20_cities = {
    'Argentina': {
        'Buenos Aires': 15490000,  # Metropolitan area
        'Córdoba': 1659000
    },
    'Australia': {
        'Sydney': 5367000,
        'Melbourne': 5078000
    },
    'Brazil': {
        'São Paulo': 22429800,  # Metropolitan area
        'Rio de Janeiro': 13634274
    },
    'Canada': {
        'Toronto': 6202000,
        'Montreal': 4221000
    },
    'China': {
        'Shanghai': 27796000,
        'Beijing': 20896000
    },
    'France': {
        'Paris': 11142000,  # Metropolitan area
        'Marseille': 1759000
    },
    'Germany': {
        'Berlin': 3669495,
        'Hamburg': 1841179
    },
    'India': {
        'Mumbai': 20411274,  # Metropolitan area
        'Delhi': 32941000
    },
    'Indonesia': {
        'Jakarta': 10562088,
        'Surabaya': 2874699
    },
    'Italy': {
        'Rome': 4342212,
        'Milan': 3140181
    },
    'Japan': {
        'Tokyo': 37393129,  # Metropolitan area
        'Yokohama': 3724844
    },
    'Mexico': {
        'Mexico City': 22085140,  # Metropolitan area
        'Guadalajara': 5243392
    },
    'Russia': {
        'Moscow': 12506468,
        'Saint Petersburg': 5351935
    },
    'Saudi Arabia': {
        'Riyadh': 7676654,
        'Jeddah': 4697957
    },
    'South Africa': {
        'Johannesburg': 5782747,
        'Cape Town': 4618000
    },
    'South Korea': {
        'Seoul': 9776000,  # Metropolitan area
        'Busan': 3385000
    },
    'Turkey': {
        'Istanbul': 15636243,
        'Ankara': 5663000
    },
    'United Kingdom': {
        'London': 9002488,
        'Birmingham': 2660000
    },
    'United States': {
        'New York City': 8804190,
        'Los Angeles': 3898747
    },
    'European Union': {
        'Brussels': 2065284,  # EU capital
        'Frankfurt': 753056   # Financial capital
    }
}

# Define product categories and subcategories
categories = {
    'Electronics': ['Smartphones', 'Laptops', 'Tablets', 'Wearables'],
    'Automotive': ['Cars', 'Motorcycles', 'Auto Parts', 'Electric Vehicles'],
    'Fashion': ['Luxury Apparel', 'Casual Wear', 'Accessories', 'Footwear'],
    'Industrial': ['Machinery', 'Raw Materials', 'Tools', 'Construction'],
    'Consumer Goods': ['Home Appliances', 'Personal Care', 'Food & Beverage', 'Home Decor']
}

# Generate the dataframe
df = pd.DataFrame(columns=['Country', 'City', 'City_Population', 'Sales', 'Date', 'Category', 'Subcategory'])

# Get the current date
today = datetime.now()

# Set random seed for reproducibility
np.random.seed(42)

# Generate synthetic data
for i in range(1000):
    # Generate country and corresponding city
    country = np.random.choice(list(g20_cities.keys()))
    city = np.random.choice(list(g20_cities[country].keys()))
    population = g20_cities[country][city]
    
    # Generate sales with more realistic variations based on category and city population
    base_sales = {
        'Electronics': np.random.normal(50000, 20000) * (population / 10000000),  # Scale with population
        'Automotive': np.random.normal(200000, 80000) * (population / 10000000),
        'Fashion': np.random.normal(30000, 10000) * (population / 10000000),
        'Industrial': np.random.normal(150000, 50000) * (population / 10000000),
        'Consumer Goods': np.random.normal(40000, 15000) * (population / 10000000)
    }
    
    # Generate category and subcategory
    category = np.random.choice(list(categories.keys()))
    subcategory = np.random.choice(categories[category])
    
    # Generate sales based on category
    sales = max(1000, round(base_sales[category]))  # Ensure minimum sales of 1000
    
    # Generate date (75% past, 25% future)
    if np.random.rand() < 0.75:
        days_past = np.random.randint(0, 730)  # Up to 2 years in the past
        date = today - timedelta(days=days_past)
    else:
        days_future = np.random.randint(0, 365)  # Up to 1 year in the future
        date = today + timedelta(days=days_future)
    
    # Append data to DataFrame
    df.loc[len(df)] = [country, city, population, sales, date, category, subcategory]

# Sort by date
df = df.sort_values('Date')

# Format date column
df['Date'] = df['Date'].dt.strftime('%Y-%m-%d')

# Save to CSV
df.to_csv('country_sales.csv', index=False)

print("Data has been successfully saved to 'country_sales.csv' with population data")
# Display first few rows as confirmation
print("\nFirst few rows of the generated data:")
print(df.head().to_markdown(index=False))