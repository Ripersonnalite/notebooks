from flask import Flask,request, render_template
from datetime import datetime
import os,requests

app = Flask(__name__)
  
@app.route('/weather', methods =['GET'])
def weather():
    city = request.args.get('city', 'Rio de Janeiro')
    if city =="":
        city = "Rio de Janeiro"
    api = ""
    construct_forecast = "https://api.openweathermap.org/data/2.5/forecast?q="+ city +"&appid=" + api + "&cnt=5"
    response_forecast = requests.get(construct_forecast)
    
    list_of_forecast = response_forecast.json()
    forecasts = list_of_forecast['list']
    #print(list_of_forecast)
    #print(type(forecasts))
    dates = {}
    tempera = {}
    weather_ = {}
    for index, forecast in enumerate(forecasts):
        # Convert the timestamp to a datetime object
        date = datetime.fromtimestamp(forecast['dt'])
        temperature = round( (forecast['main']['temp'])- 273.15,1)
        dates["date{0}".format(index)] = date.strftime('%Y-%m-%d %H:%M')
        tempera["temperature{0}".format(index)] = " • " + str(temperature)+" °c"
        weather_["weather_{0}".format(index)] = str(forecast["weather"][0]["main"])
        #weather_ = str(forecast["weather"][0]["main"])
        #print(f"Date: {date}, Temperature: {temperature} °c, Weather { weather_}")
    lazy_date1 = dates['date0']
    lazy_date2 = dates['date1']
    lazy_date3 = dates['date2']
    lazy_date4 = dates['date3']
    lazy_date5 = dates['date4']
    lazy_temp1 = tempera['temperature0']
    lazy_temp2 = tempera['temperature1']
    lazy_temp3 = tempera['temperature2']
    lazy_temp4 = tempera['temperature3']
    lazy_temp5 = tempera['temperature4']
    lazy_weather1 = weather_['weather_0']
    lazy_weather2 = weather_['weather_1']
    lazy_weather3 = weather_['weather_2']
    lazy_weather4 = weather_['weather_3']
    lazy_weather5 = weather_['weather_4']
    
    
    
    return render_template("index.html", 
                            weather = str(forecast["weather"][0]["main"]), 
                            city = str(city).upper(),
                            temp = " "+str( round( (forecast['main']['temp'])- 273.15,1)) + " °c  • ",
                            lazy_date1 = lazy_date1,
                            lazy_date2 = lazy_date2,
                            lazy_date3 = lazy_date3,
                            lazy_date4 = lazy_date4,
                            lazy_date5 = lazy_date5,
                            lazy_temp1 = lazy_temp1,
                            lazy_temp2 = lazy_temp2,
                            lazy_temp3 = lazy_temp3,
                            lazy_temp4 = lazy_temp4,
                            lazy_temp5 = lazy_temp5,
                            lazy_weather1 = lazy_weather1,
                            lazy_weather2 = lazy_weather2,
                            lazy_weather3 = lazy_weather3,
                            lazy_weather4 = lazy_weather4,
                            lazy_weather5 = lazy_weather5
                          )

if __name__ == "__main__":
    from waitress import serve
    #app.run(host= '0.0.0.0',port = 8000,debug=True)
    serve(app, host="0.0.0.0", port=8000)